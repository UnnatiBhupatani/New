<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
       // protected $table='role_permissions';

       protected $table = 'roles'; // Ensure the correct table name
       protected $fillable = ['role_name'];
    public function permissions(){
        return $this->belongsToMany(Permission::class,'role_permissions','role_id','permission_id');
    }




}
