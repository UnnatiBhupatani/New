<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subject_data extends Model
{
    protected $table='subject_datas';
    protected $fillable=['subject_name'];


    public function division(){
        return $this->belongsTo(division::class,'division_id','id');
    }
    public function posts()
{
    return $this->belongsToMany(Post::class, 'post_subject', 'subject_id', 'post_id');
}

}
