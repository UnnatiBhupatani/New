<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class student extends Model
{
   protected $table='student_data';
   protected $primaryKey="stud_id";
}
