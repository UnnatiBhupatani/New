<?php

namespace App\Models;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
   public function division(){
      return $this->belongsTo(division::class,'division');
  }

   }
