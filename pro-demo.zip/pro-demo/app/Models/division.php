<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class division extends Model
{
    protected $table='divisions';

    protected $fillable=['division_name'];

    public function subjects(){
        return $this->hasMany(Subject_data::class,'division_id','id');
    }

    public function posts()
    {
        return $this->hasMany(Post::class, 'division');
    }
}
