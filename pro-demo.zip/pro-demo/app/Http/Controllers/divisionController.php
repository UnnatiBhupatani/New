<?php

namespace App\Http\Controllers;

use App\Models\division;
use Illuminate\Http\Request;

class divisionController extends Controller
{
    public function addDivision(Request $request){

        // $request->validate([
        // 'division_name' => 'required',
        // ]);

        $div=new division;
        $div->division_name=$request->division_name;
        $div->save();
        return redirect('/division');
   }
    public function fetchDivision(){
        $div=division::all();
        return view('division',compact('div'));

    }
     public function editDivision(Request $request,$id){
            $editDiv=division::findOrFail($id);
            $div = division::all();


            return view('division',compact('editDiv','div'));
    }

    public function updateDiv(Request $request,$id){
        $updateDiv=division::findOrFail($id);
//         $request->validate([
//     'division_name' => 'required',
// ]);
          $updateDiv->division_name = $request->division_name;
             $updateDiv->save();
            return redirect('/division');


    }

    public function deleteDivision($id){
        $deleteDiv = division::find($id);
        $deleteDiv->delete();
        return redirect('/division');

    }

}
