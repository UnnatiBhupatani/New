<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class userController extends Controller
{

    public function store(Request $request){
        $data=[
            'name'=>$request->input('user_name'),
            'email'=>$request->input('user_email'),
            'phone'=>$request->input('user_phone')
        ];


        return view('home',compact('data'));
    }

    public function store_data(Request $request){
        $post=new User;
        $post->username=$request->username;
        $post->email = $request->email;
        if($request->password === $request->con_password){
            $post->password = $request->password;
            $post->save();
        return redirect('/');


        }else{ ?>
            <script>
                alert("password and confirm password must be same");

                 window.location.replace('/');
                </script><?php

        }
 }


}
