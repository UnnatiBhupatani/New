<?php

namespace App\Http\Controllers;

use App\Models\student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
     public function store(Request $request){
        $post=new student;
        $post->username=$request->username;
        $post->email = $request->email;
        if($request->password === $request->con_password){
            $post->password = $request->password;
            $post->save();
        return redirect('/');
        }else{ ?>
            <script>
                alert("password and confirm password must be same");
                 window.location.replace('/');
                </script><?php

        }
 }


}
