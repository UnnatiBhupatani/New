<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB as FacadesDB;




class empController extends Controller
{

    public function addData(Request $request){
        $name=$request->input('username');
        $email=$request->input('email');
        $password=$request->input('password');


        // $user['name'] = $name;
        // $user['email']=$email;
        // $user['password']=$password;

         DB::insert('insert into employee (name,email,password) values (?,?, ?)', [$name,$email,$password]);
         //DB::table('employee')->insert($user);
        echo "record inserted successfully";





    }


}
