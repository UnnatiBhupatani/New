<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Models\division;
use App\Models\Post;
use App\Models\Subject_data;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    // public function index(Request $request)
    // {
    //     $post = Post::with('division')->get();

    //     $div = division::all(); // Fetch all divisions
    //     // dd(Post::whereNull('division')->orWhereDoesntHave('division')->get());

       
    //     return view('register', compact('post', 'div'));
    // }

    public function index()
    {
        // Fetch all posts with their related division and subjects
        $posts = Post::with('division')->get(); 
        $divisions = Division::with('subjects')->get(); 
    
        // Add subject names to each post by finding related subjects
        foreach ($posts as $post) {
            $subjectIds = explode(',', $post->subjects); // Convert subject IDs to array
            $subjects = Subject_data::whereIn('id', $subjectIds)->pluck('subject_name')->toArray();
            $post->subject_names = implode(', ', $subjects); // Store subject names as a string
        }
    
        return view('register', compact('posts', 'divisions'));
    }
    


    public function getSubjectsByDivision($divisionId)
    {
        $subjects = Subject_data::where('division_id', $divisionId)->get();
        return response()->json($subjects);
    }


    public function store(Request $request)
    {
        // $request->validate([
        //     'username' => 'required',
        //     'email' => 'required|email',
        //     'gender' => 'required',
        //     'city' => 'required',
        //     'division_name' => 'required',
        //     'subject' => 'required|array',
        //     'password' => 'required|min:6',
        //     'con_password' => 'required|same:password',
        // ]);

        $post = new Post();
        $post->username = $request->username;
        $post->email = $request->email;
        $post->gender = $request->gender;
        $post->city = $request->city;
        $post->division = $request->division_name;
       $post->subjects = implode(',', $request->subject);
        $post->password = $request->password;
        $post->save();

        // $post->subjects()->attach($request->subject);  

        return redirect('/register')->with('success', 'Data saved successfully');
    }


   
    public function edit($id)
    {
        $display = Post::findOrFail($id);
        $post = Post::all();
        $divisions = Division::with('subjects')->get(); 
      //  $div = Division::with('subjects')->get();

        $selectedSubjects = explode(',', $display->subjects);
        $subjects = Subject_data::where('division_id', $display->division)->get();
        return view('register', compact('display', 'post', 'divisions','selectedSubjects','subjects'));
    }

    public function update(Request $request, $id)
{
    
    $display = Post::findOrFail($id);

    
    $display->username = $request->username;
    $display->email = $request->email;
    $display->gender = $request->gender;
    $display->city = $request->city;
    $display->division = $request->division_name;
    
    $display->subjects = null;

    
    if ($request->has('subject')) {
        $display->subjects = implode(',', $request->subject);
    }

    $display->password = $request->password;
    $display->save();

    return redirect('/register')->with('success', 'Data updated successfully');
}


    public function destroy($id)
    {
        $data = Post::findOrFail($id);
        $data->delete();
        return redirect('/register')->with('success', 'Data deleted successfully');
    }

    public function showRegisterForm(Request $request)
{
    $divisions = Division::all();
    $selectedSubjects = [];

    if ($request->has('division_name')) {
        $selectedSubjects = Subject_data::where('division_id', $request->division_name)->get();
    }

    return view('register', [
        'div' => $divisions,
        'selectedSubjects' => $selectedSubjects,
        'selectedDivisionId' => $request->division_name
    ]);
}

public function login(Request $request)
{
    $credentials = $request->only('username', 'password');

    if (Auth::attempt($credentials)) {
        $request->session()->regenerate();
        return redirect('/dashboard');
    }

    return redirect('/login')->with('error', 'Invalid credentials');

}

public function logout()
{
    // Clear the session
    session()->forget('username');
    
    // Optional: Clear all session data
    // session()->flush();
    
    return redirect('/login')->with('success', 'You have logged out successfully.');
}


}
?>