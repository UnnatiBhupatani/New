<?php
namespace App\Http\Controllers;

use App\Models\Permission;
use App\Models\Role;
use Illuminate\Http\Request;

class RolePermissionController extends Controller
{
    public function fetch_rolePermission(Request $request)
    {
        
        $roles = Role::all();
        $permissions = Permission::all();
        $role_permission = Role::with('permissions')->get();

       

        return view('role_permission', compact('roles', 'permissions', 'role_permission'));
    }

    public function store(Request $request)
    {
        $role = Role::find($request->role);
       // dd($role);
        if ($role) {
            $role->permissions()->sync($request->permission);
        }

        return redirect('role_permission')->with('success', 'Permissions updated successfully.');
    }
}

?>
