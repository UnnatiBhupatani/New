<?php
namespace App\Http\Controllers;

use App\Models\division;
use App\Models\subject;
use App\Models\Subject_data;
use Illuminate\Http\Request;

class subjectController extends Controller
{
    public function addSubject(Request $request)
    {

        // $request->validate([
        //     'division_Id'  => 'required',
        //     'subject_name' => 'required ',
        // ]);

        $subject               = new Subject_data();
        $subject->division_id  = $request->division_Id;
        $subject->subject_name = $request->subject_name;
        $subject->save();
        return redirect('/subject');

    }
    public function fetchSubject()
    {
        //$sub=Subject_data::all();
        $div = division::all();

        $sub = Subject_data::with('division')->get();

        return view('subject', compact('sub', 'div'));

    }

    public function editSubject(Request $request, $id)
    {
        $editSubject = Subject_data::findOrFail($id);
        $subject     = subject::all();
        $div         = division::all();
        $sub         = Subject_data::with('division')->get();
        //  dd($editSubject);

        print_r($editSubject->division_id);

        return view('subject', compact('editSubject', 'subject', 'div', 'sub'));

    }
    public function updateSubject(Request $request, $id)
    {

        // $request->validate([
        //     'division_Id'  => 'required',
        //     'subject_name' => 'required ',
        // ]);

        $updateSubject = Subject_data::findOrFail($id);
        //  $sub = Subject_data::with('division')->get();

        $updateSubject->division_id  = $request->division_Id;
        $updateSubject->subject_name = $request->subject_name;
        $updateSubject->save();

        return redirect('/subject');

    }

    public function deleteSubject($id)
    {
        $deleteSubject = Subject_data::find($id);
        $deleteSubject->delete();
        return redirect('/subject');

    }
}
