<?php

use App\Http\Controllers\PostController;
use Illuminate\Support\Facades\Route;

Route::get('/home', function () {
    return view('home');
});

Route::get('/', function () {
   
        // if (!session('username')) {
        //     return redirect('login')->withErrors(['You need to login first']);
        // }
        return view('dashboard');
   
    
   

});

// Division Routes
Route::post('add-Division', 'divisionController@addDivision');
Route::get('division', 'divisionController@fetchDivision');
Route::get('editDivision/{id}', 'divisionController@editDivision');
Route::post('updateDiv/{id}', 'divisionController@updateDiv');
Route::get('deleteDivision/{id}', 'divisionController@deleteDivision');

Route::get('/showSub', [PostController::class, 'showRegisterForm']);


// Subject Routes
Route::post('addSubject', 'subjectController@addSubject');
Route::get('editSubject/{id}', 'subjectController@editSubject');
Route::post('updateSubject/{id}', 'subjectController@updateSubject');
Route::get('deleteSubject/{id}', 'subjectController@deleteSubject');
Route::get('subject', 'subjectController@fetchSubject');

// Authentication and Post Routes
Route::get('/index', function () {
    return view('index');
});

Route::get('login-form', function () {
    return view('login');
});

Route::get('/get-subjects/{divisionId}','PostController@getSubjectsByDivision');
Route::post('store-form', 'PostController@store');
Route::get('/register', 'PostController@index');
Route::get('delete/{id}', 'PostController@destroy');
Route::get('edit/{id}', 'PostController@edit');
Route::post('login', 'PostController@login');
Route::get('logout', 'PostController@logout');
Route::post('fetchSubjectData', 'PostController@fetchSubjectData');
Route::post('update/{id}', 'PostController@update');


Route::get('/role_permission', 'RolePermissionController@fetch_rolePermission');
Route::POST('/store_role_per', 'RolePermissionController@store');
