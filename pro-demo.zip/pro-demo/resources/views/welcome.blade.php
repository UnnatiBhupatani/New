<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>welcome</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div
        style="height: 50%; width: 40%; border: solid 1px rgb(182, 179, 179); padding:30px; margin-left:30%; margin-top: 10%;">

        <form name='add-register-form' id="add-register-form" method="post" action="{{ url('store-form') }}">
            @csrf
            <h2 style="margin-left: 35%">Register</h2>

            <input type="text" class="form-control mt-4" name="username" id="username"
                placeholder="Enter username"><br>
            <input type="text" class="form-control" name="email" id="email" placeholder="Enter email"><br>
            <input type="text" class="form-control" name="password" id="password" placeholder="Enter password"><br>
            <input type="text" class="form-control" name="con_password" id="con_password"
                placeholder="Enter confirm password"><br>

            <button class="btn btn-success">Submit</button>

             <a class="btn btn-success" href="/register">Display</a>

        </form>
    </div>


</body>

</html>
