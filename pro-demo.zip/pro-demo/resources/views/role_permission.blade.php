@include('layout.navbar')

<div style="height: auto; width: 40%; border: solid 1px rgb(182, 179, 179); padding:30px; margin-left:30%; margin-top:10%;">
    <h2 style="margin-left: 35%">Role Permissions</h2><br><br>

    <!-- Form for Selecting Role and Submitting Permissions -->
    <form id="assign-permission-form" method="post" action="{{ url('store_role_per') }}">
        {{ csrf_field() }}

        <!-- Role Selection -->
        <select class="form-control" name="role" id="roleSelect">
            <option value="">Select Role</option>
            @foreach ($roles as $role)
                <option value="{{ $role->id }}" data-permissions="{{ json_encode($role->permissions->pluck('id')) }}">
                    {{ $role->role_name }}
                </option>
            @endforeach
        </select>
        <br>

        <!-- Permissions Checkboxes -->
        @foreach ($permissions as $per)
            <input type="checkbox" name="permission[]" value="{{ $per->id }}" class="permission-checkbox">
            {{ $per->permission_name }}<br>
        @endforeach

        <br>
        <button type="submit" class="btn btn-success">Save Permissions</button><br>
    </form>
</div>

<!-- Table to Display Role-Permission Data -->
<table border="1" class="table table-bordered mt-4">
    <tr>
        <th>Role</th>
        <th>Permissions</th>
    </tr>
    @foreach($role_permission as $role)
        <tr>
            <td>{{ $role->role_name }}</td>
            <td>
                @foreach ($role->permissions as $permission)
                   <li> {{ $permission->permission_name }}</li>
                @endforeach
            </td> 
        </tr>
    @endforeach
</table>

<!-- JavaScript to Handle Checkbox Selection -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const roleDropdown = document.getElementById('roleSelect'); // Dropdown for selecting roles
    const checkboxes = document.querySelectorAll('.permission-checkbox'); // All permission checkboxes

    function updatePermissions(clearCheckboxes = false) {
        let selectedRole = roleDropdown.value;

        // Clear all checkboxes if needed
        if (clearCheckboxes) {
            checkboxes.forEach(checkbox => checkbox.checked = false);
        }

        // Find selected role's assigned permissions
        if (selectedRole) {
            let selectedOption = roleDropdown.options[roleDropdown.selectedIndex];
            let assignedPermissions = JSON.parse(selectedOption.getAttribute('data-permissions') || '[]');

            // Check only the assigned permissions
            checkboxes.forEach(checkbox => {
                checkbox.checked = assignedPermissions.includes(parseInt(checkbox.value));
            });
        }
    }

    // Initialize on page load without clearing checkboxes
    updatePermissions(false);

    // Update checkboxes when role changes (clears old selections)
    roleDropdown.addEventListener('change', function() {
        updatePermissions(true);
    });
});
</script>
