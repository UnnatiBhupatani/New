<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    @include('layout.navbar')
</head>
<body style="background-color: rgb(224, 227, 243);">
{{-- <img src="{{ asset('storage/app/public/images/profile.png') }}" height="720px" width="1900px"> --}}

    <footer>
        @extends('layout.footer')
    </footer>
</body>
</html>
