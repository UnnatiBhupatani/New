
    @include('layout.master')
</head>
<body>
    @section('content')
        <div
            style="height: 50%; width: 40%; border: solid 1px rgb(182, 179, 179); padding:30px; margin-left:30%; margin-top: 5%; margin-bottom: 100px;">
            <form name="add-division-form" method="post" action="{{ isset($editDiv)? url('updateDiv/'.$editDiv->id):url('add-Division') }}">
                {{ csrf_field() }}
                <h3>Add Division</h3>
                <br>
                <input type="text" name="division_name" class="form-control" id="division_name"
                    placeholder="Enter Division"  value="{{ old ('division_name',isset($editDiv)? $editDiv->division_name:'' )}}">
                <button type="submit" class="btn btn-primary">{{ isset($editDiv)? 'update':'submit' }}</button>
            </form>
        </div>
        <table  class="table table-bordered table-striped" style="width: 50%; margin-left: 25%;">
            <tr>
                <th>division name</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>@foreach ($div as $division)
            <tr>
                <td>{{ $division->division_name }}</td>
                <td><a href="{{ url('editDivision/'.$division->id) }}" class="btn btn-warning">Update</a></td>
                <td><a href="{{ url('deleteDivision/'.$division->id) }}" class="btn btn-danger">Delete</a></td>
            </tr>@endforeach
        </table>
        <footer>
            @extends('layout.footer')
