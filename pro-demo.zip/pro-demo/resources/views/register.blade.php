@include('layout.master')
</head>
<body>
    <div style="height: 50%; width: 40%; border: solid 1px rgb(182, 179, 179); padding:30px; margin-left:30%;">
        <form name="add-register-form" id="add-register-form" method="post" action="{{ isset($display)?  url('update/' . $display   ->id): url('store-form') }}">
            {{ csrf_field() }}

            <h2 style="margin-left: 35%">Register</h2>

            <label>Username:</label>
            <input type="text" class="form-control" name="username" id="username" placeholder="Enter username"  value="{{ old('username', isset($display) ? $display->username : '') }}"><br>

            <label>Email:</label>
            <input type="text" class="form-control" name="email" id="email" placeholder="Enter email"value="{{ old('email', isset($display) ? $display->email : '') }}"><br>

            <label>Gender:</label>
            <input type="radio" name="gender" value="male" {{ old('gender', $display->gender ?? '') === 'male' ? 'checked' : '' }}> Male
            <input type="radio" name="gender" value="female" {{ old('gender', $display->gender ?? '') === 'female' ? 'checked' : '' }}> Female<br><br>

            <label>City:</label>
            <select name="city" class="form-control">
                <option value="" selected disabled>Select City</option>
                <option value="Ahmedabad" {{ old('city', $display->city ?? '') === 'Ahmedabad' ? 'selected' : '' }}>Ahmedabad</option>
                <option value="baroda" {{ old('city', $display->city ?? '') === 'baroda' ? 'selected' : '' }}>Baroda</option>
                <option value="junagadh" {{ old('city', $display->city ?? '') === 'junagadh' ? 'selected' : '' }}>Junagadh</option>
            </select><br>

            <label>Division:</label>
            <select id="division" name="division_name" class="form-control">
                <option value="">Select Division</option>
                @foreach ($divisions as $division)
                    <option value="{{ $division->id }}" {{ old('division_name', $display->division ?? '') == 
                    $division->id ? 'selected' : '' }}>{{ $division->division_name }}</option>
                @endforeach
            </select><br>
            Subjects:
            <div id="subject-container">
                @foreach ($divisions as $division)
                    <div class="subject-list" data-division="{{ $division->id}}" style="display: none;">
                        @foreach ($division->subjects as $subject)
    <li>
        <input type="checkbox" name="subject[]" value="{{ $subject->id }}"
            @if(isset($display) && in_array($subject->id, $selectedSubjects ?? [])) checked @endif>
        {{ $subject->subject_name }}
    </li>
@endforeach

                    </div>
                @endforeach
            </div>

            <label>Password:</label>
            <input type="password" class="form-control" name="password" id="password" placeholder="Enter password"  value="{{ old('password', isset($display) ? $display->password : '') }}"><br>

            <label>Confirm Password:</label>
            <input type="password" class="form-control" name="con_password" id="con_password" placeholder="Enter confirm password" value="{{ old('password', isset($display) ? $display->password : '') }}"><br>

            <button class="btn btn-success">{{ isset($display) ? 'Update' : 'Submit' }}</button>
        </form>
    </div>
 <script>
document.addEventListener('DOMContentLoaded', function() {
    const divisionChange = document.getElementById('division');
    function updateSubjectList(clearCheckboxes = false) {
        let selectedDivision = divisionChange.value;
        // Hide all subject lists
        document.querySelectorAll('.subject-list').forEach(function(list) {
            list.style.display = 'none';
            
            // Clear checkboxes only if the flag is true
            if (clearCheckboxes) {
                list.querySelectorAll('input[type="checkbox"]').forEach(function(checkbox) {
                    checkbox.checked = false;
                });
            }
        });
    // Show the subject list for the selected division
        if (selectedDivision) {
            let subjectList = document.querySelector('.subject-list[data-division="' + selectedDivision + '"]');
            if (subjectList) {
                subjectList.style.display = 'block';
            }
        }
    }

    // Initialize on page load (without clearing old checked checkboxes)
    updateSubjectList(false);

    // Update on division change (clear all checkboxes)
    divisionChange.addEventListener('change', function() {
        updateSubjectList(true);
    });
});
     </script>


</div>
<h4>User Data</h4>
   <table class="table table-bordered table-striped">
       <thead>
           <tr>
               <th>ID</th>
               <th>Name</th>
               <th>Email</th>
               <th>gender</th>
               <th>city</th>
               <th>division</th>
               <th>subject</th>
               <th>password</th>
               <th>Edit</th>
               <th>Delete</th>
           </tr>
       </thead>
       <tbody>
           @foreach ($posts as $post)
               <tr>
                   <td>{{ $post->id }}</td>
                 
                   <td>{{ $post->username }}</td>
                   <td>{{ $post->email }}</td>
                   <td>{{ $post->gender }}</td>
                    <td>{{ $post->city }}</td>
                    {{ $post->division ? $post->division->division_name : 'N/A' }}


                    {{-- <td>{{ $posts->divisions }}</td> --}}
                    {{-- <td>{{ $posts->division ? $posts->division->division_name : 'N/A' }}</td> --}}

                    <td>{{ $post->subject_names ? $post->subject_names : 'N/A' }}</td>


                    <td>{{ $post->password }}</td>
                   <td>
                       <a href="{{ url('edit/'.$post->id) }}" class="btn btn-primary">edit</a>
                   </td>
                   <td>
                      <?php $id=$post->id; ?>
                       
                      <a href="{{ url('delete',$id) }}"  class="btn btn-danger btn-sm" >delete</a>
                    </td>
               </tr>
           @endforeach
       </tbody>
   </table>

</body>
