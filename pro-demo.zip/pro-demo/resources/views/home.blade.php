<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div style="height: 50%; width: 40%; border: solid 1px gray; padding:30px; margin-left:30%; margin-top: 10%;">
        <h2>User Data:</h2>
        <ul class="list-group">
            <li class="list-group-item">name :{{ $data['name'] }}</li>
            <li class="list-group-item"> email :{{ $data['email'] }}</li>
            <li class="list-group-item">phone :{{ $data['phone'] }}</li>
            <a href="/">go back</a>
        </ul>
    </div>
</body>

</html>
