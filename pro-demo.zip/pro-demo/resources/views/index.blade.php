<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Index</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>




<div style="height: 50%; width: 40%; border: solid 1px gray; padding:30px; margin-left:30%; margin-top: 10%;">
     <h3>User Data</h3>
   <form name="user" id="user" action="home" method="post">
    @csrf

    <div class="mb-3">
    <label  class="form-label">Name:</label>
    <input type="text" class="form-control" id="user_name" name="user_name" aria-describedby="emailHelp">

  </div>
  <div class="mb-3">
    <label  class="form-label">Email:</label>
    <input type="text" class="form-control" id="user_email" name="user_email">
  </div>

  <div class="mb-3">
    <label  class="form-label">Phone No:</label>
    <input type="text" class="form-control" id="user_phone" name="user_phone">
  </div>

  <button type="submit" class="btn btn-primary">Submit</button>


   </form>
   </div>
</body>
</html>
