<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<footer style="position:static;  ">
    <div class="card mb-3" style="background-color: rgb(214, 206, 206); bottom:0;  ">

  <div class="card-body">
    <h5 class="card-title">Student Management</h5>
    <p class="card-text">Sardar Patel University</p>
    <p class="card-text"><small class="text-body-secondary">vallabh Vidhyanagar</small></p>
  </div>
</div>

</footer>
</body>
</html>
