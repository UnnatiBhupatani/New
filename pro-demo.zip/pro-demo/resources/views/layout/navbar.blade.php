<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"            rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary ">
  <div class="container-fluid" style="background-color: rgb(214, 206, 206); height:70px; ">
    <a class="navbar-brand" href="#" style="font-size: x-large" >Student Data</a>
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        </li>
         <li class="nav-item" style="font-size: larger" >
          <a class="nav-link active" aria-current="page" href="/">Home</a>
        </li>

        <li class="nav-item" style="font-size: larger"  >
          <a class="nav-link active" aria-current="page" href="/division">Division</a>
        </li>
        <li class="nav-item" style="font-size: larger" >
          <a class="nav-link active" aria-current="page" href="/subject">subjects</a>
        </li>
         <li class="nav-item" style="font-size: larger" >
          <a class="nav-link active" aria-current="page" href="/register">Register</a>
        </li>
    </ul>
    @if(session()->has('username'))
            <h5 style="margin-right: 10px;">welcome User:  {{session('username')}}</h5>
            @endif
            {{-- <img src="{{asset('public/images/profile.png') }}"> --}}
        <a class="btn btn-outline-success" type="submit" href="/logout">LogOut</a>


  </div>
</nav>


</body>
</html>
