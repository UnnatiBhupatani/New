
    @include('layout.master');

<body>
     @section('content')
        <div
            style="height: 50%; width: 40%; border: solid 1px rgb(182, 179, 179); padding:30px; margin-left:30%;  margin-bottom: 100px;">
<form name="add-subject-form" method="post" action="{{ isset($editSubject)? url('updateSubject/'.$editSubject->id):url('addSubject') }}">
    {{ csrf_field() }}
                <h3>Add subject</h3>
                <br>
                <select class="form-control" name="division_Id">
                    <option value="">select division</option>
                    @foreach ($div as $division)
                    <option value="{{ $division->id }}"
                        {{ old ('division_id',$editSubject->division_id ?? '') === $division->id? 'selected':'' }}>{{ $division->division_name }}</option>
                    @endforeach
                </select>

                <input type="text" name="subject_name" value="{{ old('subject_name',isset($editSubject)? $editSubject->subject_name:'') }}" placeholder="Enter subject name" class="form-control">
                <button type="submit" class="btn btn-primary">{{ isset($editSubject)? 'update':'submit' }}</button>
            </form><br>
        </div>
        <table class="table table-bordered table-striped" style="width: 50%; margin-left: 25%;">
                <tr>
                    <th>division id</th>
                    <th>division name</th>
                    <th>subject name</th>
                    <th>Update</th>
                    <th>Delete</th>
                </tr> @foreach ($sub as $subject)
                <tr>
                    <td>{{ $subject->division_id }}</td>
                    <td>{{ $subject->division->division_name }}</td>
                    <td>{{ $subject->subject_name }}</td>
                    <td><a href="{{ url('editSubject/'.$subject->id) }}" class="btn btn-warning">Update</a></td>
                <td><a href="{{ url('deleteSubject/'.$subject->id) }}" class="btn btn-danger">Delete</a></td>
                     @endforeach
                </tr>
            </table>



