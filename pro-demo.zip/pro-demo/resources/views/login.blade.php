<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"            rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <div style="height: 50%; width: 40%; border: solid 1px rgb(182, 179, 179); padding:30px; margin-left:30%; margin-top:10%;">

        <form name='login-form' id="login-form" method="post" action="{{ url('login') }}">
            {{ csrf_field() }}
            <h2 style="margin-left: 35%">LogIn</h2>

            <input type="text" class="form-control mt-4 @error('username') is-invalid @enderror" name="username" id="username" placeholder="Enter username">
            @if ($errors->has('username'))
            <span style="color:red;">{{ $errors->first('username') }}</span>@endif<br>

            <input type="password" class="form-control  @error('username') is-invalid @enderror" name="password" id="password" placeholder="Enter password" >@if ($errors->has('password'))
                <span style="color:red;">{{ $errors->first('password') }}</span>@endif<br>
                {{-- <span style="color:red;">@error('username'){{$message}}@enderror</span> --}}
            <button class="btn btn-success">Login</button><br>

            not have any Account?<a href="{{ url('/register') }}">Register</a>
        </form>

    </div>
</body>
</html>
