<?php echo $__env->make('layout.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div style="height: auto; width: 40%; border: solid 1px rgb(182, 179, 179); padding:30px; margin-left:30%; margin-top:10%;">
    <h2 style="margin-left: 35%">Role Permissions</h2><br><br>

    <!-- Form for Selecting Role and Submitting Permissions -->
    <form id="assign-permission-form" method="post" action="<?php echo e(url('store_role_per')); ?>">
        <?php echo e(csrf_field()); ?>


        <!-- Role Selection -->
        <select class="form-control" name="role" id="roleSelect">
            <option value="">Select Role</option>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role->id); ?>" data-permissions="<?php echo e(json_encode($role->permissions->pluck('id'))); ?>">
                    <?php echo e($role->role_name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>

        <!-- Permissions Checkboxes -->
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="checkbox" name="permission[]" value="<?php echo e($per->id); ?>" class="permission-checkbox">
            <?php echo e($per->permission_name); ?><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <br>
        <button type="submit" class="btn btn-success">Save Permissions</button><br>
    </form>
</div>

<!-- Table to Display Role-Permission Data -->
<table border="1" class="table table-bordered mt-4">
    <tr>
        <th>Role</th>
        <th>Permissions</th>
    </tr>
    <?php $__currentLoopData = $role_permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($role->role_name); ?></td>
            <td>
                <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <li> <?php echo e($permission->permission_name); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td> 
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<!-- JavaScript to Handle Checkbox Selection -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const roleDropdown = document.getElementById('roleSelect'); // Dropdown for selecting roles
    const checkboxes = document.querySelectorAll('.permission-checkbox'); // All permission checkboxes

    function updatePermissions(clearCheckboxes = false) {
        let selectedRole = roleDropdown.value;

        // Clear all checkboxes if needed
        if (clearCheckboxes) {
            checkboxes.forEach(checkbox => checkbox.checked = false);
        }

        // Find selected role's assigned permissions
        if (selectedRole) {
            let selectedOption = roleDropdown.options[roleDropdown.selectedIndex];
            let assignedPermissions = JSON.parse(selectedOption.getAttribute('data-permissions') || '[]');

            // Check only the assigned permissions
            checkboxes.forEach(checkbox => {
                checkbox.checked = assignedPermissions.includes(parseInt(checkbox.value));
            });
        }
    }

    // Initialize on page load without clearing checkboxes
    updatePermissions(false);

    // Update checkboxes when role changes (clears old selections)
    roleDropdown.addEventListener('change', function() {
        updatePermissions(true);
    });
});
</script>
