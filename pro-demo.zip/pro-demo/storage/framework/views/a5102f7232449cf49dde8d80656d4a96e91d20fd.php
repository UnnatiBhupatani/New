
    <?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

<body>
     <?php $__env->startSection('content'); ?>
        <div
            style="height: 50%; width: 40%; border: solid 1px rgb(182, 179, 179); padding:30px; margin-left:30%;  margin-bottom: 100px;">
<form name="add-subject-form" method="post" action="<?php echo e(isset($editSubject)? url('updateSubject/'.$editSubject->id):url('addSubject')); ?>">
    <?php echo e(csrf_field()); ?>

                <h3>Add subject</h3>
                <br>
                <select class="form-control" name="division_Id">
                    <option value="">select division</option>
                    <?php $__currentLoopData = $div; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($division->id); ?>"
                        <?php echo e(old ('division_id',$editSubject->division_id ?? '') === $division->id? 'selected':''); ?>><?php echo e($division->division_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <input type="text" name="subject_name" value="<?php echo e(old('subject_name',isset($editSubject)? $editSubject->subject_name:'')); ?>" placeholder="Enter subject name" class="form-control">
                <button type="submit" class="btn btn-primary"><?php echo e(isset($editSubject)? 'update':'submit'); ?></button>
            </form><br>
        </div>
        <table class="table table-bordered table-striped" style="width: 50%; margin-left: 25%;">
                <tr>
                    <th>division id</th>
                    <th>division name</th>
                    <th>subject name</th>
                    <th>Update</th>
                    <th>Delete</th>
                </tr> <?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($subject->division_id); ?></td>
                    <td><?php echo e($subject->division->division_name); ?></td>
                    <td><?php echo e($subject->subject_name); ?></td>
                    <td><a href="<?php echo e(url('editSubject/'.$subject->id)); ?>" class="btn btn-warning">Update</a></td>
                <td><a href="<?php echo e(url('deleteSubject/'.$subject->id)); ?>" class="btn btn-danger">Delete</a></td>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </table>



