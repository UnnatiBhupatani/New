    <?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <?php $__env->startSection('content'); ?>
        <div
            style="height: 50%; width: 40%; border: solid 1px rgb(182, 179, 179); padding:30px; margin-left:30%; margin-top: 5%; margin-bottom: 100px;">
            <form name="add-division-form" method="post" action="<?php echo e(isset($editDiv)? url('updateDiv/'.$editDiv->id):url('add-Division')); ?>">
                <?php echo e(csrf_field()); ?>

                <h3>Add Division</h3>
                <br>
                <input type="text" name="division_name" class="form-control" id="division_name"
                    placeholder="Enter Division"  value="<?php echo e(old ('division_name',isset($editDiv)? $editDiv->division_name:'' )); ?>">
                <button type="submit" class="btn btn-primary"><?php echo e(isset($editDiv)? 'update':'submit'); ?></button>
            </form>
        </div>
        <table  class="table table-bordered table-striped" style="width: 50%; margin-left: 25%;">
            <tr>
                <th>division name</th>
                <th>Update</th>
                <th>Delete</th>
            </tr><?php $__currentLoopData = $div; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($division->division_name); ?></td>
                <td><a href="<?php echo e(url('editDivision/'.$division->id)); ?>" class="btn btn-warning">Update</a></td>
                <td><a href="<?php echo e(url('deleteDivision/'.$division->id)); ?>" class="btn btn-danger">Delete</a></td>
            </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <footer>
            

<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>